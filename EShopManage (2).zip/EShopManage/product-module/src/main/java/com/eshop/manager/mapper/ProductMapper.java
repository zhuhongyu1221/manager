package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.Product;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

public interface ProductMapper extends BaseMapper<Product> {

    @Update("UPDATE product SET status = #{status} WHERE id = #{id} AND is_deleted = 0")
    int updateStatus(@Param("id") Long id, @Param("status") Integer status);

    @Update("UPDATE product SET stock = stock + #{delta} WHERE id = #{id}")
    int updateStock(@Param("id") Long id, @Param("delta") Integer delta);

    @Update("UPDATE product SET sales = sales + #{delta} WHERE id = #{id}")
    int updateSales(@Param("id") Long id, @Param("delta") Integer delta);
}
