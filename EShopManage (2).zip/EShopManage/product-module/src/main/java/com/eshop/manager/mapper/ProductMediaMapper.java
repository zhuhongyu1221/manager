package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.ProductMedia;

public interface ProductMediaMapper extends BaseMapper<ProductMedia> {
}
