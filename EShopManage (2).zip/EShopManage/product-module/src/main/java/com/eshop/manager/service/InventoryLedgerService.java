package com.eshop.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshop.manager.entity.InventoryLedger;

import java.util.List;

public interface InventoryLedgerService {
    IPage<InventoryLedger> page(int page, int pageSize, Long productId, Long skuId,
                                Integer changeType, String startDate, String endDate);

    /** 入库 */
    boolean inbound(Long productId, Long skuId, int quantity, String remark, String operator);
    /** 出库 */
    boolean outbound(Long productId, Long skuId, int quantity, String remark, String operator);
    /** 盘点调整 */
    boolean adjust(Long productId, Long skuId, int newStock, String remark, String operator);
}
