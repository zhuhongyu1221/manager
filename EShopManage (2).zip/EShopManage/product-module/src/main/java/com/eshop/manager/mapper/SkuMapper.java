package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.Sku;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface SkuMapper extends BaseMapper<Sku> {

    @Update("UPDATE sku SET stock = stock + #{delta} WHERE id = #{id} AND stock + #{delta} >= 0")
    int updateStock(@Param("id") Long id, @Param("delta") Integer delta);

    @Update("UPDATE sku SET locked_stock = locked_stock + #{delta} WHERE id = #{id} AND locked_stock + #{delta} >= 0")
    int updateLockedStock(@Param("id") Long id, @Param("delta") Integer delta);

    @Update("UPDATE sku SET sales = sales + #{delta} WHERE id = #{id}")
    int updateSales(@Param("id") Long id, @Param("delta") Integer delta);

    void batchInsert(@Param("list") List<Sku> skuList);
}
