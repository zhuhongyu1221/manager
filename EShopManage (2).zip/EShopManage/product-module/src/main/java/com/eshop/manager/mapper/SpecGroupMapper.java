package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.SpecGroup;

public interface SpecGroupMapper extends BaseMapper<SpecGroup> {
}
