package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.InventoryLedger;

public interface InventoryLedgerMapper extends BaseMapper<InventoryLedger> {
}
