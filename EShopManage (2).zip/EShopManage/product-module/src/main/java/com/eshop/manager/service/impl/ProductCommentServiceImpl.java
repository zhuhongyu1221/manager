package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eshop.manager.entity.ProductComment;
import com.eshop.manager.mapper.ProductCommentMapper;
import com.eshop.manager.service.ProductCommentService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class ProductCommentServiceImpl implements ProductCommentService {

    private final ProductCommentMapper commentMapper;

    public ProductCommentServiceImpl(ProductCommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }

    @Override
    public ProductComment getById(Long id) {
        return commentMapper.selectById(id);
    }

    @Override
    public IPage<ProductComment> page(int page, int pageSize, Long productId, Integer status) {
        LambdaQueryWrapper<ProductComment> qw = new LambdaQueryWrapper<>();
        if (productId != null && productId > 0) qw.eq(ProductComment::getProductId, productId);
        if (status != null) qw.eq(ProductComment::getStatus, status);
        qw.orderByDesc(ProductComment::getCreateTime);
        return commentMapper.selectPage(new Page<>(page, pageSize), qw);
    }

    @Override
    public boolean add(ProductComment comment) {
        comment.setId(null);
        return commentMapper.insert(comment) > 0;
    }

    @Override
    public boolean audit(Long id, Integer status) {
        ProductComment comment = commentMapper.selectById(id);
        if (comment == null) throw new IllegalArgumentException("评论不存在");
        return commentMapper.update(null, new LambdaUpdateWrapper<ProductComment>()
                .eq(ProductComment::getId, id)
                .set(ProductComment::getStatus, status)) > 0;
    }

    @Override
    public boolean reply(Long id, String replyContent) {
        return commentMapper.update(null, new LambdaUpdateWrapper<ProductComment>()
                .eq(ProductComment::getId, id)
                .set(ProductComment::getReplyContent, replyContent)
                .set(ProductComment::getReplyTime, LocalDateTime.now())) > 0;
    }

    @Override
    public boolean delete(Long id) {
        return commentMapper.deleteById(id) > 0;
    }
}
