package com.eshop.manager.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("product_media")
public class ProductMedia {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long productId;

    private Long mediaId;

    private Integer type;

    private Integer sortOrder;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
