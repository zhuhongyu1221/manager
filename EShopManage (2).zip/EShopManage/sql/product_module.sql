-- ============================================================
-- 电商管理系统 - 商品基础模块 数据库建表脚本
-- 引擎: InnoDB | 字符集: utf8mb4 | 适用于 MySQL 5.7+ / 8.x
-- ============================================================
-- 不存在则创建数据库
CREATE DATABASE IF NOT EXISTS eshop DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- 切换到eshop库，后续建表都会在这个库内
USE eshop;
-- ------------------------------------------------------------
-- 1. 品牌表 (brand)
-- ------------------------------------------------------------
CREATE TABLE `brand` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '品牌ID',
  `name`        varchar(100)        NOT NULL                 COMMENT '品牌名称',
  `name_en`     varchar(100)        DEFAULT ''               COMMENT '品牌英文名',
  `logo`        varchar(500)        DEFAULT ''               COMMENT '品牌Logo URL',
  `description` text                                         COMMENT '品牌简介',
  `website`     varchar(500)        DEFAULT ''               COMMENT '官方网站',
  `country`     varchar(100)        DEFAULT ''               COMMENT '所属国家/地区',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '排序权重(越小越前)',
  `status`      tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '状态: 0=禁用, 1=启用',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`  tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除: 0=正常, 1=已删',
  PRIMARY KEY (`id`),
  KEY `idx_name`       (`name`),
  KEY `idx_status`     (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品品牌表';


-- ------------------------------------------------------------
-- 2. 商品分类表 (category) — 多级分类，自引用
-- ------------------------------------------------------------
CREATE TABLE `category` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '分类ID',
  `parent_id`   bigint(20) unsigned NOT NULL DEFAULT '0'     COMMENT '父分类ID(0=顶级)',
  `name`        varchar(100)        NOT NULL                 COMMENT '分类名称',
  `icon`        varchar(500)        DEFAULT ''               COMMENT '分类图标',
  `image`       varchar(500)        DEFAULT ''               COMMENT '分类配图',
  `description` varchar(500)        DEFAULT ''               COMMENT '分类描述',
  `level`       tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '层级(1=一级, 2=二级, 3=三级)',
  `path`        varchar(500)        DEFAULT ''               COMMENT '层级路径, 格式: 0/父ID/自身ID/',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '排序权重',
  `status`      tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '状态: 0=禁用, 1=启用',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`  tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id`  (`parent_id`),
  KEY `idx_level`      (`level`),
  KEY `idx_status`     (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品分类表 — 支持无限级分类, 业务通常3~4层';


-- ------------------------------------------------------------
-- 3. 规格组表 (spec_group) — 颜色/尺寸/版本等规格大类
-- ------------------------------------------------------------
CREATE TABLE `spec_group` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '规格组ID',
  `name`        varchar(100)        NOT NULL                 COMMENT '规格组名称, 如"颜色""尺寸""套餐"',
  `type`        tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '规格类型: 1=销售规格(影响SKU), 2=非销售属性(不生成SKU)',
  `input_type`  tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '录入方式: 1=下拉选择, 2=手工录入',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '排序权重',
  `status`      tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '状态: 0=禁用, 1=启用',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`  tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_sort_order` (`sort_order`),
  KEY `idx_type`       (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='规格组 — 颜色/尺寸/版本等规格大类';


-- ------------------------------------------------------------
-- 4. 规格值表 (spec_value) — 红色/XL/256G 等具体规格值
-- ------------------------------------------------------------
CREATE TABLE `spec_value` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '规格值ID',
  `group_id`    bigint(20) unsigned NOT NULL                 COMMENT '所属规格组ID',
  `name`        varchar(100)        NOT NULL                 COMMENT '规格值名称, 如"红色""XL""256G"',
  `image`       varchar(500)        DEFAULT ''               COMMENT '规格值配图(颜色/款式等需要展示图片)',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '排序权重',
  `status`      tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '状态: 0=禁用, 1=启用',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`  tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_group_id`   (`group_id`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `fk_spec_value_group` FOREIGN KEY (`group_id`) REFERENCES `spec_group`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='规格值 — 红色/XL/256G 等具体规格取值';


-- ------------------------------------------------------------
-- 5. 商品主表 (product)
-- ------------------------------------------------------------
CREATE TABLE `product` (
  `id`              bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '商品ID',
  `name`            varchar(200)        NOT NULL                 COMMENT '商品名称',
  `subtitle`        varchar(500)        DEFAULT ''               COMMENT '副标题/卖点描述',
  `brand_id`        bigint(20) unsigned DEFAULT '0'              COMMENT '品牌ID',
  `category_id`     bigint(20) unsigned DEFAULT '0'              COMMENT '所属分类ID',
  `category_path`   varchar(500)        DEFAULT ''               COMMENT '完整分类路径, 格式 "1/10/100"',
  `unit`            varchar(20)         DEFAULT '件'              COMMENT '计量单位',
  `main_image`      varchar(500)        DEFAULT ''               COMMENT '商品主图URL',
  `images`          json                                         COMMENT '商品图片列表(JSON 数组)',
  `description`     text                                         COMMENT '商品详情(富文本/HTML)',
  `keywords`        varchar(500)        DEFAULT ''               COMMENT 'SEO/搜索关键词, 逗号分隔',
  `price`           decimal(10,2)       NOT NULL DEFAULT '0.00'  COMMENT '销售价(取最低SKU价)',
  `original_price`  decimal(10,2)       DEFAULT '0.00'           COMMENT '市场价/划线价',
  `cost_price`      decimal(10,2)       DEFAULT '0.00'           COMMENT '成本价(取最低SKU成本)',
  `stock`           int(11)             NOT NULL DEFAULT '0'     COMMENT '总库存(sum(sku.stock))',
  `sales`           int(11)             NOT NULL DEFAULT '0'     COMMENT '累计销量',
  `weight`          decimal(10,2)       DEFAULT '0.00'           COMMENT '重量(kg)',
  `volume`          decimal(10,2)       DEFAULT '0.00'           COMMENT '体积(m³)',
  `status`          tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '商品状态: -2=回收站, -1=下架, 0=草稿, 1=上架, 2=定时上架',
  `is_new`          tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '是否新品: 0=否, 1=是',
  `is_hot`          tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '是否热卖: 0=否, 1=是',
  `is_recommend`    tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '是否推荐: 0=否, 1=是',
  `audit_status`    tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '审核状态: 0=无需审核/未提交, 1=待审核, 2=通过, 3=驳回',
  `audit_remark`    varchar(500)        DEFAULT ''               COMMENT '审核意见/驳回原因',
  `publish_time`    datetime            DEFAULT NULL             COMMENT '实际上架时间',
  `scheduled_time`  datetime            DEFAULT NULL             COMMENT '定时上架时间',
  `create_user`     varchar(50)         DEFAULT ''               COMMENT '创建人',
  `update_user`     varchar(50)         DEFAULT ''               COMMENT '最后更新人',
  `create_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`      tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_name`          (`name`(100)),
  KEY `idx_brand_id`      (`brand_id`),
  KEY `idx_category_id`   (`category_id`),
  KEY `idx_status`        (`status`),
  KEY `idx_audit_status`  (`audit_status`),
  KEY `idx_price`         (`price`),
  KEY `idx_sales`         (`sales`),
  KEY `idx_create_time`   (`create_time`),
  KEY `idx_publish_time`  (`publish_time`),
  CONSTRAINT `fk_product_brand`    FOREIGN KEY (`brand_id`)    REFERENCES `brand`(`id`)    ON UPDATE CASCADE,
  CONSTRAINT `fk_product_category` FOREIGN KEY (`category_id`) REFERENCES `category`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品主表 — 核心商品信息';


-- ------------------------------------------------------------
-- 6. 商品-规格关联表 (product_spec)
--    记录某个商品使用了哪些规格组和规格值
-- ------------------------------------------------------------
CREATE TABLE `product_spec` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '关联ID',
  `product_id`  bigint(20) unsigned NOT NULL                 COMMENT '商品ID',
  `group_id`    bigint(20) unsigned NOT NULL                 COMMENT '规格组ID',
  `value_id`    bigint(20) unsigned NOT NULL                 COMMENT '规格值ID',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '排序权重',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_value` (`product_id`, `value_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_group_id`   (`group_id`),
  KEY `idx_value_id`   (`value_id`),
  CONSTRAINT `fk_ps_product` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`)    ON UPDATE CASCADE,
  CONSTRAINT `fk_ps_group`   FOREIGN KEY (`group_id`)   REFERENCES `spec_group`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ps_value`   FOREIGN KEY (`value_id`)   REFERENCES `spec_value`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品-规格关联 — 商品使用了哪些规格';


-- ------------------------------------------------------------
-- 7. SKU 表 (sku) — 库存单位, 每个规格组合一条
-- ------------------------------------------------------------
CREATE TABLE `sku` (
  `id`              bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT 'SKU ID',
  `product_id`      bigint(20) unsigned NOT NULL                 COMMENT '商品ID',
  `sku_code`        varchar(100)        NOT NULL                 COMMENT 'SKU 编码(唯一)',
  `barcode`         varchar(100)        DEFAULT ''               COMMENT '条码/EAN/ISBN',
  `spec_desc`       varchar(500)        DEFAULT ''               COMMENT '规格描述 JSON, 如 {"颜色":"红","尺寸":"XL"}',
  `spec_value_ids`  varchar(200)        DEFAULT ''               COMMENT '规格值ID组合, 如 "5_9" 用于快速匹配',
  `price`           decimal(10,2)       NOT NULL DEFAULT '0.00'  COMMENT '销售价',
  `original_price`  decimal(10,2)       DEFAULT '0.00'           COMMENT '原价/划线价',
  `cost_price`      decimal(10,2)       DEFAULT '0.00'           COMMENT '成本价',
  `stock`           int(11)             NOT NULL DEFAULT '0'     COMMENT '物理库存',
  `locked_stock`    int(11)             NOT NULL DEFAULT '0'     COMMENT '锁定库存(下单未支付)',
  `weight`          decimal(10,2)       DEFAULT '0.00'           COMMENT '重量(kg)',
  `volume`          decimal(10,2)       DEFAULT '0.00'           COMMENT '体积(m³)',
  `image`           varchar(500)        DEFAULT ''               COMMENT 'SKU 专属图片',
  `sales`           int(11)             NOT NULL DEFAULT '0'     COMMENT '销量',
  `status`          tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '状态: 0=禁用, 1=启用',
  `create_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`      tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sku_code`   (`sku_code`),
  KEY `idx_product_id`       (`product_id`),
  KEY `idx_price`            (`price`),
  KEY `idx_barcode`          (`barcode`),
  KEY `idx_status`           (`status`),
  CONSTRAINT `fk_sku_product` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='SKU — 库存单位, 每个规格组合一条记录';


-- ------------------------------------------------------------
-- 8. 素材图库表 (media) — 统一管理图片/视频/文档
-- ------------------------------------------------------------
CREATE TABLE `media` (
  `id`              bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '素材ID',
  `name`            varchar(200)        NOT NULL                 COMMENT '文件展示名称',
  `original_name`   varchar(200)        NOT NULL                 COMMENT '原始文件名',
  `url`             varchar(500)        NOT NULL                 COMMENT '访问URL',
  `thumbnail_url`   varchar(500)        DEFAULT ''               COMMENT '缩略图URL',
  `mime_type`       varchar(50)         NOT NULL                 COMMENT 'MIME 类型, 如 image/jpeg, video/mp4',
  `file_type`       tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '文件大类: 1=图片, 2=视频, 3=文档',
  `size`            bigint(20)          NOT NULL DEFAULT '0'     COMMENT '文件大小(字节)',
  `width`           int(11)             DEFAULT '0'              COMMENT '图片宽度(px)',
  `height`          int(11)             DEFAULT '0'              COMMENT '图片高度(px)',
  `duration`        int(11)             DEFAULT '0'              COMMENT '视频时长(秒)',
  `storage_driver`  varchar(50)         DEFAULT 'local'          COMMENT '存储驱动: local, oss, cos, s3',
  `bucket`          varchar(100)        DEFAULT ''               COMMENT '存储桶/目录名',
  `object_key`      varchar(500)        DEFAULT ''               COMMENT '对象存储 Key',
  `md5`             varchar(64)         DEFAULT ''               COMMENT '文件 MD5(去重用)',
  `tags`            varchar(500)        DEFAULT ''               COMMENT '标签, 逗号分隔',
  `category_id`     bigint(20) unsigned DEFAULT '0'              COMMENT '素材分类ID',
  `create_user`     varchar(50)         DEFAULT ''               COMMENT '上传人',
  `create_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted`      tinyint(4)          NOT NULL DEFAULT '0'     COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_file_type`    (`file_type`),
  KEY `idx_mime_type`    (`mime_type`),
  KEY `idx_category_id`  (`category_id`),
  KEY `idx_create_user`  (`create_user`),
  KEY `idx_create_time`  (`create_time`),
  KEY `idx_md5`          (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='素材图库 — 统一管理商品图片/视频/文档等素材';


-- ------------------------------------------------------------
-- 9. 商品-素材关联表 (product_media)
-- ------------------------------------------------------------
CREATE TABLE `product_media` (
  `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '关联ID',
  `product_id`  bigint(20) unsigned NOT NULL                 COMMENT '商品ID',
  `media_id`    bigint(20) unsigned NOT NULL                 COMMENT '素材ID',
  `type`        tinyint(4)          NOT NULL DEFAULT '1'     COMMENT '用途: 1=主图, 2=详情图, 3=轮播图, 4=SKU图, 5=视频',
  `sort_order`  int(11)             NOT NULL DEFAULT '0'     COMMENT '展示排序',
  `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_media_type` (`product_id`, `media_id`, `type`),
  KEY `idx_product_id`     (`product_id`),
  KEY `idx_media_id`       (`media_id`),
  KEY `idx_type`           (`type`),
  CONSTRAINT `fk_pm_product` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_pm_media`   FOREIGN KEY (`media_id`)   REFERENCES `media`(`id`)   ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品-素材关联 — 商品图片/视频的多对多关系';


-- ------------------------------------------------------------
-- 10. 库存台账表 (inventory_ledger)
--     所有库存变动的流水记录, 用于对账和审计追溯
-- ------------------------------------------------------------
CREATE TABLE `inventory_ledger` (
  `id`              bigint(20) unsigned NOT NULL AUTO_INCREMENT  COMMENT '台账ID',
  `product_id`      bigint(20) unsigned NOT NULL                 COMMENT '商品ID',
  `sku_id`          bigint(20) unsigned DEFAULT '0'              COMMENT 'SKU ID(0=整商品操作)',
  `change_type`     tinyint(4)          NOT NULL                 COMMENT '变更类型: 1=入库, 2=出库, 3=盘点调整, 4=退货入库, 5=取消释放, 6=初始化',
  `quantity`        int(11)             NOT NULL                 COMMENT '变更数量(正=增库, 负=减库)',
  `stock_before`    int(11)             NOT NULL                 COMMENT '变更前库存',
  `stock_after`     int(11)             NOT NULL                 COMMENT '变更后库存',
  `reference_type`  varchar(50)         DEFAULT ''               COMMENT '单据类型: order/purchase/return/adjust/check',
  `reference_no`    varchar(100)        DEFAULT ''               COMMENT '单据编号',
  `reference_id`    bigint(20) unsigned DEFAULT '0'              COMMENT '关联单ID(订单ID/采购单ID等)',
  `remark`          varchar(500)        DEFAULT ''               COMMENT '备注/操作说明',
  `operator`        varchar(50)         DEFAULT ''               COMMENT '操作人',
  `operate_time`    datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `create_time`     datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_product_id`     (`product_id`),
  KEY `idx_sku_id`         (`sku_id`),
  KEY `idx_change_type`    (`change_type`),
  KEY `idx_reference_no`   (`reference_no`),
  KEY `idx_reference_id`   (`reference_id`),
  KEY `idx_operate_time`   (`operate_time`),
  KEY `idx_operator`       (`operator`),
  CONSTRAINT `fk_il_product` FOREIGN KEY (`product_id`) REFERENCES `product`(`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_il_sku`     FOREIGN KEY (`sku_id`)     REFERENCES `sku`(`id`)     ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存台账 — 库存变动流水, 审计追溯';


-- 注意: product_comment 表归属成员4的评价售后模块, 这里不建
