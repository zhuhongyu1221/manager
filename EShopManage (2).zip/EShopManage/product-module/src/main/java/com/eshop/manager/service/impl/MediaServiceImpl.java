package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eshop.manager.entity.Media;
import com.eshop.manager.mapper.MediaMapper;
import com.eshop.manager.service.MediaService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class MediaServiceImpl implements MediaService {

    private final MediaMapper mediaMapper;

    public MediaServiceImpl(MediaMapper mediaMapper) {
        this.mediaMapper = mediaMapper;
    }

    @Override
    public Media getById(Long id) {
        return mediaMapper.selectById(id);
    }

    @Override
    public IPage<Media> page(int page, int pageSize, Integer fileType, String keyword) {
        LambdaQueryWrapper<Media> qw = new LambdaQueryWrapper<>();
        if (fileType != null) qw.eq(Media::getFileType, fileType);
        if (StringUtils.hasText(keyword)) {
            qw.like(Media::getName, keyword)
              .or().like(Media::getOriginalName, keyword);
        }
        qw.orderByDesc(Media::getCreateTime);
        return mediaMapper.selectPage(new Page<>(page, pageSize), qw);
    }

    @Override
    public boolean add(Media media) {
        media.setId(null);
        return mediaMapper.insert(media) > 0;
    }

    @Override
    public boolean delete(Long id) {
        return mediaMapper.deleteById(id) > 0;
    }
}
