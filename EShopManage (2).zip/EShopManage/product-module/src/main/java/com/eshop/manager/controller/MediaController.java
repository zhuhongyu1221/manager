package com.eshop.manager.controller;

import com.eshop.manager.common.PageResult;
import com.eshop.manager.common.Result;
import com.eshop.manager.entity.Media;
import com.eshop.manager.service.MediaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@Api(tags = "素材图库")
@RestController
@RequestMapping("/api/media")
public class MediaController {

    private final MediaService mediaService;

    public MediaController(MediaService mediaService) {
        this.mediaService = mediaService;
    }

    @GetMapping("/{id}")
    @ApiOperation("素材详情")
    public Result<Media> getById(@PathVariable Long id) {
        return Result.success(mediaService.getById(id));
    }

    @GetMapping("/page")
    @ApiOperation("素材分页查询")
    public Result<PageResult<Media>> page(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Integer fileType,
            @RequestParam(required = false) String keyword) {
        return Result.success(PageResult.of(mediaService.page(page, pageSize, fileType, keyword)));
    }

    @PostMapping
    @ApiOperation("上传素材(模拟)")
    public Result<Void> upload(@RequestBody Media media) {
        media.setCreateUser("admin");
        mediaService.add(media);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除素材")
    public Result<Void> delete(@PathVariable Long id) {
        mediaService.delete(id);
        return Result.success();
    }
}
