package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eshop.manager.entity.Product;
import com.eshop.manager.enums.AuditStatusEnum;
import com.eshop.manager.enums.ProductStatusEnum;
import com.eshop.manager.mapper.ProductMapper;
import com.eshop.manager.service.ProductService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductMapper productMapper;

    public ProductServiceImpl(ProductMapper productMapper) {
        this.productMapper = productMapper;
    }

    @Override
    public Product getById(Long id) {
        return productMapper.selectById(id);
    }

    @Override
    public IPage<Product> page(int page, int pageSize, String keyword, Long brandId,
                               Long categoryId, Integer status, Integer auditStatus) {
        LambdaQueryWrapper<Product> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            qw.like(Product::getName, keyword)
              .or().like(Product::getKeywords, keyword)
              .or().like(Product::getSubtitle, keyword);
        }
        if (brandId != null && brandId > 0) qw.eq(Product::getBrandId, brandId);
        if (categoryId != null && categoryId > 0) qw.eq(Product::getCategoryId, categoryId);
        if (status != null) qw.eq(Product::getStatus, status);
        if (auditStatus != null) qw.eq(Product::getAuditStatus, auditStatus);
        qw.orderByDesc(Product::getCreateTime);
        return productMapper.selectPage(new Page<>(page, pageSize), qw);
    }

    @Override
    public boolean add(Product product) {
        product.setId(null);
        product.setStatus(ProductStatusEnum.DRAFT.getValue());
        product.setAuditStatus(AuditStatusEnum.NOT_SUBMITTED.getValue());
        product.setStock(0);
        product.setSales(0);
        return productMapper.insert(product) > 0;
    }

    @Override
    public boolean update(Product product) {
        Product old = productMapper.selectById(product.getId());
        if (old == null) throw new IllegalArgumentException("商品不存在");
        // 已上架的商品更新后需重新审核（如果业务需要）
        return productMapper.updateById(product) > 0;
    }

    @Override
    public boolean delete(Long id) {
        return productMapper.deleteById(id) > 0;
    }

    @Override
    public boolean publish(Long id) {
        Product product = productMapper.selectById(id);
        if (product == null) throw new IllegalArgumentException("商品不存在");
        if (product.getAuditStatus() != AuditStatusEnum.APPROVED.getValue()
                && product.getAuditStatus() != AuditStatusEnum.NOT_SUBMITTED.getValue()) {
            throw new IllegalArgumentException("商品未通过审核，无法上架");
        }
        int rows = productMapper.updateStatus(id, ProductStatusEnum.ON_SHELF.getValue());
        if (rows > 0) {
            productMapper.update(null, new LambdaUpdateWrapper<Product>()
                    .eq(Product::getId, id)
                    .set(Product::getPublishTime, LocalDateTime.now()));
        }
        return rows > 0;
    }

    @Override
    public boolean unpublish(Long id) {
        return productMapper.updateStatus(id, ProductStatusEnum.OFF_SHELF.getValue()) > 0;
    }

    @Override
    public boolean submitAudit(Long id) {
        Product product = productMapper.selectById(id);
        if (product == null) throw new IllegalArgumentException("商品不存在");
        return productMapper.update(null, new LambdaUpdateWrapper<Product>()
                .eq(Product::getId, id)
                .set(Product::getAuditStatus, AuditStatusEnum.PENDING.getValue())) > 0;
    }

    @Override
    public boolean approveAudit(Long id, String remark) {
        return productMapper.update(null, new LambdaUpdateWrapper<Product>()
                .eq(Product::getId, id)
                .set(Product::getAuditStatus, AuditStatusEnum.APPROVED.getValue())
                .set(Product::getAuditRemark, remark)) > 0;
    }

    @Override
    public boolean rejectAudit(Long id, String remark) {
        return productMapper.update(null, new LambdaUpdateWrapper<Product>()
                .eq(Product::getId, id)
                .set(Product::getAuditStatus, AuditStatusEnum.REJECTED.getValue())
                .set(Product::getAuditRemark, remark)) > 0;
    }

    @Override
    public boolean batchUpdateStatus(List<Long> ids, int status) {
        return productMapper.update(null, new LambdaUpdateWrapper<Product>()
                .in(Product::getId, ids)
                .set(Product::getStatus, status)) > 0;
    }

    @Override
    public boolean batchDelete(List<Long> ids) {
        return productMapper.delete(new LambdaQueryWrapper<Product>()
                .in(Product::getId, ids)) > 0;
    }
}
