package com.eshop.manager.controller;

import com.eshop.manager.common.PageResult;
import com.eshop.manager.common.Result;
import com.eshop.manager.entity.Brand;
import com.eshop.manager.service.BrandService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "品牌管理")
@RestController
@RequestMapping("/api/brand")
public class BrandController {

    private final BrandService brandService;

    public BrandController(BrandService brandService) {
        this.brandService = brandService;
    }

    @GetMapping("/{id}")
    @ApiOperation("获取品牌详情")
    public Result<Brand> getById(@PathVariable Long id) {
        return Result.success(brandService.getById(id));
    }

    @GetMapping("/page")
    @ApiOperation("品牌分页查询")
    public Result<PageResult<Brand>> page(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {
        return Result.success(PageResult.of(brandService.page(page, pageSize, keyword, status)));
    }

    @GetMapping("/list")
    @ApiOperation("品牌列表(启用)")
    public Result<List<Brand>> list() {
        return Result.success(brandService.listAll());
    }

    @PostMapping
    @ApiOperation("新增品牌")
    public Result<Void> add(@RequestBody Brand brand) {
        brandService.add(brand);
        return Result.success();
    }

    @PutMapping
    @ApiOperation("修改品牌")
    public Result<Void> update(@RequestBody Brand brand) {
        brandService.update(brand);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除品牌")
    public Result<Void> delete(@PathVariable Long id) {
        brandService.delete(id);
        return Result.success();
    }

    @PutMapping("/batch-status")
    @ApiOperation("批量启用/禁用")
    public Result<Void> batchStatus(@RequestBody BatchStatusRequest req) {
        brandService.batchEnable(req.getIds(), req.getStatus());
        return Result.success();
    }

    @lombok.Data
    public static class BatchStatusRequest {
        private List<Long> ids;
        private Integer status;
    }
}
