package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eshop.manager.entity.Brand;
import com.eshop.manager.mapper.BrandMapper;
import com.eshop.manager.service.BrandService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class BrandServiceImpl implements BrandService {

    private final BrandMapper brandMapper;

    public BrandServiceImpl(BrandMapper brandMapper) {
        this.brandMapper = brandMapper;
    }

    @Override
    public Brand getById(Long id) {
        return brandMapper.selectById(id);
    }

    @Override
    public IPage<Brand> page(int page, int pageSize, String keyword, Integer status) {
        LambdaQueryWrapper<Brand> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            qw.like(Brand::getName, keyword).or().like(Brand::getNameEn, keyword);
        }
        if (status != null) {
            qw.eq(Brand::getStatus, status);
        }
        qw.orderByAsc(Brand::getSortOrder);
        return brandMapper.selectPage(new Page<>(page, pageSize), qw);
    }

    @Override
    public List<Brand> listAll() {
        return brandMapper.selectList(
                new LambdaQueryWrapper<Brand>()
                        .eq(Brand::getStatus, 1)
                        .orderByAsc(Brand::getSortOrder));
    }

    @Override
    public boolean add(Brand brand) {
        brand.setId(null);
        return brandMapper.insert(brand) > 0;
    }

    @Override
    public boolean update(Brand brand) {
        return brandMapper.updateById(brand) > 0;
    }

    @Override
    public boolean delete(Long id) {
        return brandMapper.deleteById(id) > 0;
    }

    @Override
    public boolean batchEnable(List<Long> ids, Integer status) {
        return brandMapper.update(null,
                new LambdaUpdateWrapper<Brand>().in(Brand::getId, ids)
                        .set(Brand::getStatus, status)) > 0;
    }
}
