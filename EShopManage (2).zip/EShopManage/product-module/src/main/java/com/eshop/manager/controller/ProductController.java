package com.eshop.manager.controller;

import com.eshop.manager.common.PageResult;
import com.eshop.manager.common.Result;
import com.eshop.manager.entity.Product;
import com.eshop.manager.service.ProductService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "商品管理")
@RestController
@RequestMapping("/api/product")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/{id}")
    @ApiOperation("获取商品详情")
    public Result<Product> getById(@PathVariable Long id) {
        return Result.success(productService.getById(id));
    }

    @GetMapping("/page")
    @ApiOperation("商品分页查询")
    public Result<PageResult<Product>> page(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long brandId,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) Integer auditStatus) {
        return Result.success(PageResult.of(
                productService.page(page, pageSize, keyword, brandId, categoryId, status, auditStatus)));
    }

    @PostMapping
    @ApiOperation("新增商品")
    public Result<Void> add(@RequestBody Product product) {
        productService.add(product);
        return Result.success();
    }

    @PutMapping
    @ApiOperation("修改商品")
    public Result<Void> update(@RequestBody Product product) {
        productService.update(product);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除商品")
    public Result<Void> delete(@PathVariable Long id) {
        productService.delete(id);
        return Result.success();
    }

    // ========== 状态管控 ==========

    @PutMapping("/{id}/publish")
    @ApiOperation("上架")
    public Result<Void> publish(@PathVariable Long id) {
        productService.publish(id);
        return Result.success();
    }

    @PutMapping("/{id}/unpublish")
    @ApiOperation("下架")
    public Result<Void> unpublish(@PathVariable Long id) {
        productService.unpublish(id);
        return Result.success();
    }

    @PutMapping("/{id}/submit-audit")
    @ApiOperation("提交审核")
    public Result<Void> submitAudit(@PathVariable Long id) {
        productService.submitAudit(id);
        return Result.success();
    }

    @PutMapping("/{id}/approve-audit")
    @ApiOperation("审核通过")
    public Result<Void> approveAudit(@PathVariable Long id, @RequestParam(required = false) String remark) {
        productService.approveAudit(id, remark);
        return Result.success();
    }

    @PutMapping("/{id}/reject-audit")
    @ApiOperation("审核驳回")
    public Result<Void> rejectAudit(@PathVariable Long id, @RequestParam String remark) {
        productService.rejectAudit(id, remark);
        return Result.success();
    }

    // ========== 批量处理 ==========

    @PutMapping("/batch-status")
    @ApiOperation("批量上下架")
    public Result<Void> batchStatus(@RequestBody BatchStatusReq req) {
        productService.batchUpdateStatus(req.getIds(), req.getStatus());
        return Result.success();
    }

    @DeleteMapping("/batch")
    @ApiOperation("批量删除")
    public Result<Void> batchDelete(@RequestBody BatchIdsReq req) {
        productService.batchDelete(req.getIds());
        return Result.success();
    }

    @lombok.Data
    public static class BatchStatusReq {
        private List<Long> ids;
        private int status;
    }

    @lombok.Data
    public static class BatchIdsReq {
        private List<Long> ids;
    }
}
