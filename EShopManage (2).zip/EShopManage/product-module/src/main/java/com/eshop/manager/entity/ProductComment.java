package com.eshop.manager.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("product_comment")
public class ProductComment {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long productId;

    private Long skuId;

    private Long userId;

    private Long orderId;

    private Long orderItemId;

    private String content;

    private Integer rating;

    private String images;

    private Integer isAnonymous;

    private Integer isTop;

    private Integer status;

    private String replyContent;

    private LocalDateTime replyTime;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableLogic
    private Integer isDeleted;
}
