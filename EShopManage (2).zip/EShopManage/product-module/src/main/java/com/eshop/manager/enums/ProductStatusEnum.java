package com.eshop.manager.enums;

import com.baomidou.mybatisplus.annotation.IEnum;

public enum ProductStatusEnum implements IEnum<Integer> {
    DRAFT(0, "草稿"),
    ON_SHELF(1, "上架"),
    SCHEDULED(2, "定时上架"),
    OFF_SHELF(-1, "下架"),
    RECYCLED(-2, "回收站");

    private final int value;
    private final String label;

    ProductStatusEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }
}
