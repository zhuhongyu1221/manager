package com.eshop.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshop.manager.entity.Media;

public interface MediaService {
    Media getById(Long id);
    IPage<Media> page(int page, int pageSize, Integer fileType, String keyword);
    boolean add(Media media);
    boolean delete(Long id);
}
