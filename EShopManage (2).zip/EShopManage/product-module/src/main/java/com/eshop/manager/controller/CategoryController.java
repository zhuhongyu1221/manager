package com.eshop.manager.controller;

import com.eshop.manager.common.Result;
import com.eshop.manager.entity.Category;
import com.eshop.manager.service.CategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "分类管理")
@RestController
@RequestMapping("/api/category")
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping("/{id}")
    @ApiOperation("获取分类详情")
    public Result<Category> getById(@PathVariable Long id) {
        return Result.success(categoryService.getById(id));
    }

    @GetMapping("/children")
    @ApiOperation("获取子分类列表")
    public Result<List<Category>> children(@RequestParam(required = false, defaultValue = "0") Long parentId) {
        return Result.success(categoryService.listByParentId(parentId));
    }

    @GetMapping("/tree")
    @ApiOperation("获取分类树形结构")
    public Result<List<Map<String, Object>>> tree() {
        List<Category> roots = categoryService.listByParentId(0L);
        List<Map<String, Object>> tree = buildTree(roots);
        return Result.success(tree);
    }

    @PostMapping
    @ApiOperation("新增分类")
    public Result<Void> add(@RequestBody Category category) {
        categoryService.add(category);
        return Result.success();
    }

    @PutMapping
    @ApiOperation("修改分类")
    public Result<Void> update(@RequestBody Category category) {
        categoryService.update(category);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除分类")
    public Result<Void> delete(@PathVariable Long id) {
        categoryService.delete(id);
        return Result.success();
    }

    /** 递归构建树形结构 */
    private List<Map<String, Object>> buildTree(List<Category> list) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Category cat : list) {
            Map<String, Object> node = new HashMap<>();
            node.put("id", cat.getId());
            node.put("name", cat.getName());
            node.put("parentId", cat.getParentId());
            node.put("level", cat.getLevel());
            node.put("sortOrder", cat.getSortOrder());
            node.put("status", cat.getStatus());
            List<Category> children = categoryService.listByParentId(cat.getId());
            if (!children.isEmpty()) {
                node.put("children", buildTree(children));
            }
            result.add(node);
        }
        return result;
    }
}
