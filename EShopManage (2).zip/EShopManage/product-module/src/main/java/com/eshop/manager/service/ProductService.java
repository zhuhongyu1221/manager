package com.eshop.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshop.manager.entity.Product;
import com.eshop.manager.entity.Sku;

import java.util.List;

public interface ProductService {
    Product getById(Long id);
    IPage<Product> page(int page, int pageSize, String keyword, Long brandId,
                        Long categoryId, Integer status, Integer auditStatus);
    boolean add(Product product);
    boolean update(Product product);
    boolean delete(Long id);

    /** 上架 */
    boolean publish(Long id);
    /** 下架 */
    boolean unpublish(Long id);
    /** 提交审核 */
    boolean submitAudit(Long id);
    /** 审核通过 */
    boolean approveAudit(Long id, String remark);
    /** 审核驳回 */
    boolean rejectAudit(Long id, String remark);

    /** 批量上下架 */
    boolean batchUpdateStatus(List<Long> ids, int status);
    /** 批量删除 */
    boolean batchDelete(List<Long> ids);
}
