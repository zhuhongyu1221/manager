package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.eshop.manager.entity.Product;
import com.eshop.manager.entity.ProductSpec;
import com.eshop.manager.entity.Sku;
import com.eshop.manager.entity.SpecGroup;
import com.eshop.manager.entity.SpecValue;
import com.eshop.manager.mapper.ProductMapper;
import com.eshop.manager.mapper.ProductSpecMapper;
import com.eshop.manager.mapper.SkuMapper;
import com.eshop.manager.mapper.SpecGroupMapper;
import com.eshop.manager.mapper.SpecValueMapper;
import com.eshop.manager.service.SpecService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SpecServiceImpl implements SpecService {

    private final SpecGroupMapper specGroupMapper;
    private final SpecValueMapper specValueMapper;
    private final ProductSpecMapper productSpecMapper;
    private final SkuMapper skuMapper;
    private final ProductMapper productMapper;

    public SpecServiceImpl(SpecGroupMapper specGroupMapper, SpecValueMapper specValueMapper,
                           ProductSpecMapper productSpecMapper, SkuMapper skuMapper,
                           ProductMapper productMapper) {
        this.specGroupMapper = specGroupMapper;
        this.specValueMapper = specValueMapper;
        this.productSpecMapper = productSpecMapper;
        this.skuMapper = skuMapper;
        this.productMapper = productMapper;
    }

    // ==================== 规格组 ====================

    @Override
    public List<SpecGroup> listGroups() {
        return specGroupMapper.selectList(
                new LambdaQueryWrapper<SpecGroup>().orderByAsc(SpecGroup::getSortOrder));
    }

    @Override
    public SpecGroup getGroupById(Long id) {
        return specGroupMapper.selectById(id);
    }

    @Override
    public boolean addGroup(SpecGroup group) {
        group.setId(null);
        return specGroupMapper.insert(group) > 0;
    }

    @Override
    public boolean updateGroup(SpecGroup group) {
        return specGroupMapper.updateById(group) > 0;
    }

    @Override
    public boolean deleteGroup(Long id) {
        // 删除组下的所有值
        specValueMapper.delete(new LambdaQueryWrapper<SpecValue>().eq(SpecValue::getGroupId, id));
        return specGroupMapper.deleteById(id) > 0;
    }

    // ==================== 规格值 ====================

    @Override
    public List<SpecValue> listValues(Long groupId) {
        return specValueMapper.selectList(
                new LambdaQueryWrapper<SpecValue>()
                        .eq(SpecValue::getGroupId, groupId)
                        .orderByAsc(SpecValue::getSortOrder));
    }

    @Override
    public SpecValue getValueById(Long id) {
        return specValueMapper.selectById(id);
    }

    @Override
    public boolean addValue(SpecValue value) {
        value.setId(null);
        return specValueMapper.insert(value) > 0;
    }

    @Override
    public boolean updateValue(SpecValue value) {
        return specValueMapper.updateById(value) > 0;
    }

    @Override
    public boolean deleteValue(Long id) {
        return specValueMapper.deleteById(id) > 0;
    }

    // ==================== 商品规格关联 ====================

    @Override
    public List<ProductSpec> listProductSpecs(Long productId) {
        return productSpecMapper.selectList(
                new LambdaQueryWrapper<ProductSpec>()
                        .eq(ProductSpec::getProductId, productId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveProductSpecs(Long productId, List<Long> valueIds) {
        // 删除旧的关联
        productSpecMapper.delete(new LambdaQueryWrapper<ProductSpec>()
                .eq(ProductSpec::getProductId, productId));

        // 插入新的关联
        if (valueIds != null && !valueIds.isEmpty()) {
            List<ProductSpec> list = new ArrayList<>();
            int sort = 0;
            for (Long valueId : valueIds) {
                SpecValue value = specValueMapper.selectById(valueId);
                if (value != null) {
                    ProductSpec ps = new ProductSpec();
                    ps.setProductId(productId);
                    ps.setGroupId(value.getGroupId());
                    ps.setValueId(valueId);
                    ps.setSortOrder(sort++);
                    list.add(ps);
                }
            }
            if (!list.isEmpty()) {
                for (ProductSpec ps : list) {
                    productSpecMapper.insert(ps);
                }
            }
        }

        // 自动生成 SKU
        generateSkus(productId);

        return true;
    }

    // ==================== SKU 批量生成 ====================

    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<Sku> generateSkus(Long productId) {
        Product product = productMapper.selectById(productId);
        if (product == null) throw new IllegalArgumentException("商品不存在");

        // 获取商品关联的所有规格值, 按组分组
        List<ProductSpec> specs = productSpecMapper.selectList(
                new LambdaQueryWrapper<ProductSpec>()
                        .eq(ProductSpec::getProductId, productId)
                        .orderByAsc(ProductSpec::getSortOrder));

        if (specs.isEmpty()) {
            // 无规格商品，生成单条 SKU
            Sku existSku = skuMapper.selectOne(
                    new LambdaQueryWrapper<Sku>().eq(Sku::getProductId, productId));
            if (existSku != null) return Collections.singletonList(existSku);

            Sku sku = new Sku();
            sku.setProductId(productId);
            sku.setSkuCode(generateSkuCode(productId, null));
            sku.setPrice(product.getPrice());
            sku.setOriginalPrice(product.getOriginalPrice());
            sku.setCostPrice(product.getCostPrice());
            sku.setStock(0);
            sku.setStatus(1);
            sku.setSpecDesc("{}");
            sku.setSpecValueIds("");
            skuMapper.insert(sku);
            return Collections.singletonList(sku);
        }

        // 按 groupId 分组
        Map<Long, List<ProductSpec>> groupMap = specs.stream()
                .collect(Collectors.groupingBy(ProductSpec::getGroupId));

        // 获取每组的值 ID 列表
        List<List<Long>> valueIdGroups = new ArrayList<>();
        for (List<ProductSpec> groupSpecs : groupMap.values()) {
            List<Long> valueIds = groupSpecs.stream()
                    .map(ProductSpec::getValueId)
                    .distinct()
                    .collect(Collectors.toList());
            valueIdGroups.add(valueIds);
        }

        // 笛卡尔积生成所有组合
        List<List<Long>> combinations = cartesianProduct(valueIdGroups);

        // 删除旧 SKU
        skuMapper.delete(new LambdaQueryWrapper<Sku>().eq(Sku::getProductId, productId));

        // 生成新 SKU
        List<Sku> newSkus = new ArrayList<>();
        for (List<Long> combo : combinations) {
            List<Long> sortedIds = new ArrayList<>(combo);
            Collections.sort(sortedIds);
            String specValueIds = sortedIds.stream()
                    .map(String::valueOf)
                    .collect(Collectors.joining("_"));

            // 构建 spec_desc 描述
            Map<String, String> descMap = new LinkedHashMap<>();
            for (Long valueId : combo) {
                SpecValue sv = specValueMapper.selectById(valueId);
                if (sv != null) {
                    SpecGroup sg = specGroupMapper.selectById(sv.getGroupId());
                    if (sg != null) {
                        descMap.put(sg.getName(), sv.getName());
                    }
                }
            }
            String specDesc = descMap.entrySet().stream()
                    .map(e -> "\"" + e.getKey() + "\":\"" + e.getValue() + "\"")
                    .collect(Collectors.joining(",", "{", "}"));

            Sku sku = new Sku();
            sku.setProductId(productId);
            sku.setSkuCode(generateSkuCode(productId, sortedIds));
            sku.setSpecDesc(specDesc);
            sku.setSpecValueIds(specValueIds);
            sku.setPrice(product.getPrice());
            sku.setOriginalPrice(product.getOriginalPrice());
            sku.setCostPrice(product.getCostPrice());
            sku.setStock(0);
            sku.setSales(0);
            sku.setStatus(1);
            newSkus.add(sku);
        }

        if (!newSkus.isEmpty()) {
            skuMapper.batchInsert(newSkus);
        }

        return newSkus;
    }

    private String generateSkuCode(Long productId, List<Long> valueIds) {
        String base = "SKU" + String.format("%06d", productId);
        if (valueIds != null && !valueIds.isEmpty()) {
            base += valueIds.stream().map(id -> String.format("%04d", id))
                    .collect(Collectors.joining(""));
        }
        return base;
    }

    private List<List<Long>> cartesianProduct(List<List<Long>> lists) {
        List<List<Long>> result = new ArrayList<>();
        if (lists.isEmpty()) return result;

        result.add(new ArrayList<>());
        for (List<Long> list : lists) {
            List<List<Long>> temp = new ArrayList<>();
            for (List<Long> res : result) {
                for (Long item : list) {
                    List<Long> newList = new ArrayList<>(res);
                    newList.add(item);
                    temp.add(newList);
                }
            }
            result = temp;
        }
        return result;
    }
}
