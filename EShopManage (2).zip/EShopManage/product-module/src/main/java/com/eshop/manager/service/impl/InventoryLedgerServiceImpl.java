package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eshop.manager.entity.InventoryLedger;
import com.eshop.manager.entity.Sku;
import com.eshop.manager.enums.ChangeTypeEnum;
import com.eshop.manager.mapper.InventoryLedgerMapper;
import com.eshop.manager.mapper.ProductMapper;
import com.eshop.manager.mapper.SkuMapper;
import com.eshop.manager.service.InventoryLedgerService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

@Service
public class InventoryLedgerServiceImpl implements InventoryLedgerService {

    private final InventoryLedgerMapper ledgerMapper;
    private final SkuMapper skuMapper;
    private final ProductMapper productMapper;

    public InventoryLedgerServiceImpl(InventoryLedgerMapper ledgerMapper,
                                      SkuMapper skuMapper, ProductMapper productMapper) {
        this.ledgerMapper = ledgerMapper;
        this.skuMapper = skuMapper;
        this.productMapper = productMapper;
    }

    @Override
    public IPage<InventoryLedger> page(int page, int pageSize, Long productId, Long skuId,
                                       Integer changeType, String startDate, String endDate) {
        LambdaQueryWrapper<InventoryLedger> qw = new LambdaQueryWrapper<>();
        if (productId != null && productId > 0) qw.eq(InventoryLedger::getProductId, productId);
        if (skuId != null && skuId > 0) qw.eq(InventoryLedger::getSkuId, skuId);
        if (changeType != null) qw.eq(InventoryLedger::getChangeType, changeType);
        if (StringUtils.hasText(startDate)) {
            qw.ge(InventoryLedger::getOperateTime, startDate + " 00:00:00");
        }
        if (StringUtils.hasText(endDate)) {
            qw.le(InventoryLedger::getOperateTime, endDate + " 23:59:59");
        }
        qw.orderByDesc(InventoryLedger::getOperateTime);
        return ledgerMapper.selectPage(new Page<>(page, pageSize), qw);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean inbound(Long productId, Long skuId, int quantity, String remark, String operator) {
        return changeStock(productId, skuId, quantity, ChangeTypeEnum.INBOUND, remark, operator);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean outbound(Long productId, Long skuId, int quantity, String remark, String operator) {
        return changeStock(productId, skuId, -quantity, ChangeTypeEnum.OUTBOUND, remark, operator);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean adjust(Long productId, Long skuId, int newStock, String remark, String operator) {
        Sku sku = skuMapper.selectById(skuId);
        if (sku == null) throw new IllegalArgumentException("SKU不存在");

        int delta = newStock - sku.getStock();

        // 更新 SKU 库存
        int rows;
        if (delta >= 0) {
            rows = skuMapper.updateStock(skuId, delta);
        } else {
            rows = skuMapper.updateStock(skuId, delta);
        }
        if (rows <= 0) throw new RuntimeException("库存更新失败");

        // 更新商品总库存
        productMapper.updateStock(productId, delta);

        // 记录台账
        InventoryLedger ledger = buildLedger(productId, skuId,
                ChangeTypeEnum.ADJUST, delta, sku.getStock(), sku.getStock() + delta,
                remark, operator);
        ledgerMapper.insert(ledger);

        return true;
    }

    private boolean changeStock(Long productId, Long skuId, int delta, ChangeTypeEnum type,
                                String remark, String operator) {
        Sku sku = skuMapper.selectById(skuId);
        if (sku == null) throw new IllegalArgumentException("SKU不存在");

        int stockBefore = sku.getStock();

        // 更新 SKU 库存 (乐观锁)
        int rows = skuMapper.updateStock(skuId, delta);
        if (rows <= 0) throw new RuntimeException("库存不足或更新失败");

        // 更新商品总库存
        productMapper.updateStock(productId, delta);

        // 重新查询最新库存
        Sku updatedSku = skuMapper.selectById(skuId);

        // 记录台账
        InventoryLedger ledger = buildLedger(productId, skuId, type, delta,
                stockBefore, updatedSku.getStock(), remark, operator);
        ledgerMapper.insert(ledger);

        return true;
    }

    private InventoryLedger buildLedger(Long productId, Long skuId, ChangeTypeEnum type,
                                        int quantity, int stockBefore, int stockAfter,
                                        String remark, String operator) {
        InventoryLedger ledger = new InventoryLedger();
        ledger.setProductId(productId);
        ledger.setSkuId(skuId);
        ledger.setChangeType(type.getValue());
        ledger.setQuantity(quantity);
        ledger.setStockBefore(stockBefore);
        ledger.setStockAfter(stockAfter);
        ledger.setRemark(remark);
        ledger.setOperator(operator);
        ledger.setOperateTime(LocalDateTime.now());
        return ledger;
    }
}
