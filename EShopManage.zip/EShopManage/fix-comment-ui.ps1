# Use short path to avoid Chinese character issues
$root = (Get-Item -Path ".\product-module\src\main\resources\static").FullName
$path = Join-Path $root "index.html"

Write-Host "Path: $path"

$utf8 = [System.Text.Encoding]::UTF8
$content = [System.IO.File]::ReadAllText($path, $utf8)
Write-Host "Read $($content.Length) chars"

# 1. Add comment menu item
$content = $content -replace "(.+素材图库.+)", "`$1`n            { key: 'comment',   label: '评论管理',   icon: '💬' },"
Write-Host "Step 1 done (menu)"

# 2. Add comment template before inventory section
$invHeader = "<!-- ===== 库存台账 ===== -->"
$commentTmpl = @"
                <!-- ===== 评论管理 ===== -->
                <div v-if="currentMenu === 'comment'">
                    <div class="page-card">
                        <div class="search-bar">
                            <el-input v-model="cmtQuery.productId" placeholder="商品ID" style="width:120px" clearable />
                            <el-select v-model="cmtQuery.status" placeholder="状态" clearable @change="fetchComments">
                                <el-option label="待审核" :value="0" />
                                <el-option label="已通过" :value="1" />
                                <el-option label="已驳回" :value="2" />
                            </el-select>
                            <el-button type="primary" @click="fetchComments">查询</el-button>
                        </div>
                        <el-table :data="cmtList" stripe v-loading="cmtLoading">
                            <el-table-column prop="id" label="ID" width="70" />
                            <el-table-column prop="productId" label="商品ID" width="80" />
                            <el-table-column prop="content" label="评论内容" min-width="250" show-overflow-tooltip />
                            <el-table-column label="评分" width="80"><template v-slot="{row}">⭐{{ row.rating }}</template></el-table-column>
                            <el-table-column label="状态" width="90">
                                <template v-slot="{row}">
                                    <span v-if="row.status === 1" class="status-tag status-on">已通过</span>
                                    <span v-else-if="row.status === 2" class="status-tag status-off">已驳回</span>
                                    <span v-else class="status-tag status-pending">待审核</span>
                                </template>
                            </el-table-column>
                            <el-table-column prop="createTime" label="时间" width="170" />
                            <el-table-column label="操作" width="240" fixed="right">
                                <template v-slot="{row}">
                                    <el-button size="small" v-if="row.status === 0" @click="auditComment(row.id, 1)" type="success" plain>通过</el-button>
                                    <el-button size="small" v-if="row.status === 0" @click="auditComment(row.id, 2)" type="danger" plain>驳回</el-button>
                                    <el-button size="small" @click="openReplyDialog(row)">回复</el-button>
                                    <el-popconfirm title="确定删除?" @confirm="deleteComment(row.id)">
                                        <template #reference><el-button size="small" type="danger">删除</el-button></template>
                                    </el-popconfirm>
                                </template>
                            </el-table-column>
                        </el-table>
                        <el-pagination v-if="cmtTotal > 0" style="margin-top:16px;justify-content:flex-end"
                            v-model:page-size="cmtQuery.pageSize" :total="cmtTotal"
                            v-model:current-page="cmtQuery.page" layout="total,prev,pager,next" @current-change="fetchComments" />
                    </div>
                    <el-dialog v-model="replyDialog.visible" title="商家回复" width="450px">
                        <el-input type="textarea" v-model="replyDialog.content" rows="4" placeholder="请输入回复内容" />
                        <template #footer>
                            <el-button @click="replyDialog.visible = false">取消</el-button>
                            <el-button type="primary" @click="submitReply">回复</el-button>
                        </template>
                    </el-dialog>
                </div>

$invHeader
"@
$content = $content -replace [regex]::Escape($invHeader), $commentTmpl
Write-Host "Step 2 done (template)"

# 3. Add comment JS functions before Media section
$jsComment = @"
        // ======== Comment ========
        const cmtList = ref([]);
        const cmtTotal = ref(0);
        const cmtLoading = ref(false);
        const cmtQuery = reactive({ page:1, pageSize:20, productId:'', status:null });
        const replyDialog = reactive({ visible:false, commentId:null, content:'' });

        async function fetchComments() {
            cmtLoading.value = true;
            const params = { page: cmtQuery.page, pageSize: cmtQuery.pageSize };
            if (cmtQuery.productId) params.productId = cmtQuery.productId;
            if (cmtQuery.status !== null && cmtQuery.status !== '') params.status = cmtQuery.status;
            const res = await api.get('/api/comment/page', { params });
            cmtList.value = res.data.data.list || [];
            cmtTotal.value = res.data.data.total || 0;
            cmtLoading.value = false;
        }
        async function auditComment(id, status) {
            await api.put('/api/comment/' + id + '/audit', null, { params: { status } });
            ElMessage.success(status === 1 ? '已通过' : '已驳回');
            fetchComments();
        }
        function openReplyDialog(row) {
            replyDialog.commentId = row.id;
            replyDialog.content = '';
            replyDialog.visible = true;
        }
        async function submitReply() {
            await api.put('/api/comment/' + replyDialog.commentId + '/reply', null, { params: { content: replyDialog.content } });
            replyDialog.visible = false;
            ElMessage.success('回复成功');
            fetchComments();
        }
        async function deleteComment(id) {
            await api.delete('/api/comment/' + id);
            ElMessage.success('已删除');
            fetchComments();
        }

        // ======== Media ========
"@
$content = $content -replace "// ======== Media ========", $jsComment
Write-Host "Step 3 done (JS)"

# 4. Add fetchComments in onMounted after fetchInventory
$content = $content -replace "(fetchInventory\(\);)","`$1`n            fetchComments();"
Write-Host "Step 4 done (onMounted)"

# 5. Add comment vars to return section
$content = $content -replace "(deleteMedia,)", "`$1`n            cmtList, cmtTotal, cmtLoading, cmtQuery, replyDialog,`n            fetchComments, auditComment, openReplyDialog, submitReply, deleteComment,"
Write-Host "Step 5 done (return)"

[System.IO.File]::WriteAllText($path, $content, $utf8)
Write-Host "Written successfully"
