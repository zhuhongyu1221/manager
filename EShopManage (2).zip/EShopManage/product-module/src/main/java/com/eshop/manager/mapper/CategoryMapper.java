package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.Category;

public interface CategoryMapper extends BaseMapper<Category> {
}
