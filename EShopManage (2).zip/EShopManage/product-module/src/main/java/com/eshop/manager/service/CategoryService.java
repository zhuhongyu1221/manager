package com.eshop.manager.service;

import com.eshop.manager.entity.Category;

import java.util.List;

public interface CategoryService {
    Category getById(Long id);
    List<Category> listByParentId(Long parentId);
    List<Category> tree(Long parentId);
    boolean add(Category category);
    boolean update(Category category);
    boolean delete(Long id);
}
