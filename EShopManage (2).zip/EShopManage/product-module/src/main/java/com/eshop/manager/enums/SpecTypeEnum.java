package com.eshop.manager.enums;

public enum SpecTypeEnum {
    SALE(1, "销售规格"),
    ATTRIBUTE(2, "非销售属性");

    private final int value;
    private final String label;

    SpecTypeEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public int getValue() { return value; }
    public String getLabel() { return label; }
}
