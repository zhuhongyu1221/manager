package com.eshop.manager.enums;

import com.baomidou.mybatisplus.annotation.IEnum;

public enum ChangeTypeEnum implements IEnum<Integer> {
    INBOUND(1, "入库"),
    OUTBOUND(2, "出库"),
    ADJUST(3, "盘点调整"),
    RETURN(4, "退货入库"),
    CANCEL_RELEASE(5, "取消释放"),
    INIT(6, "初始化");

    private final int value;
    private final String label;

    ChangeTypeEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }
}
