package com.eshop.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshop.manager.entity.ProductComment;

public interface ProductCommentService {
    ProductComment getById(Long id);
    IPage<ProductComment> page(int page, int pageSize, Long productId, Integer status);
    boolean add(ProductComment comment);
    boolean audit(Long id, Integer status);
    boolean reply(Long id, String replyContent);
    boolean delete(Long id);
}
