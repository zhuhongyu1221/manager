package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.ProductSpec;

public interface ProductSpecMapper extends BaseMapper<ProductSpec> {
}
