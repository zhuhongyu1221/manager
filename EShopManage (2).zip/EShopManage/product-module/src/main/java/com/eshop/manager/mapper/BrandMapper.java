package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.Brand;

public interface BrandMapper extends BaseMapper<Brand> {
}
