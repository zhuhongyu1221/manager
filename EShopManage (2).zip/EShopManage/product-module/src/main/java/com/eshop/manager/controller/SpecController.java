package com.eshop.manager.controller;

import com.eshop.manager.common.Result;
import com.eshop.manager.entity.ProductSpec;
import com.eshop.manager.entity.Sku;
import com.eshop.manager.entity.SpecGroup;
import com.eshop.manager.entity.SpecValue;
import com.eshop.manager.service.SpecService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "规格配置")
@RestController
@RequestMapping("/api/spec")
public class SpecController {

    private final SpecService specService;

    public SpecController(SpecService specService) {
        this.specService = specService;
    }

    // ========== 规格组 ==========

    @GetMapping("/group/list")
    @ApiOperation("规格组列表")
    public Result<List<SpecGroup>> listGroups() {
        return Result.success(specService.listGroups());
    }

    @GetMapping("/group/{id}")
    @ApiOperation("规格组详情")
    public Result<SpecGroup> getGroup(@PathVariable Long id) {
        return Result.success(specService.getGroupById(id));
    }

    @PostMapping("/group")
    @ApiOperation("新增规格组")
    public Result<Void> addGroup(@RequestBody SpecGroup group) {
        specService.addGroup(group);
        return Result.success();
    }

    @PutMapping("/group")
    @ApiOperation("修改规格组")
    public Result<Void> updateGroup(@RequestBody SpecGroup group) {
        specService.updateGroup(group);
        return Result.success();
    }

    @DeleteMapping("/group/{id}")
    @ApiOperation("删除规格组")
    public Result<Void> deleteGroup(@PathVariable Long id) {
        specService.deleteGroup(id);
        return Result.success();
    }

    // ========== 规格值 ==========

    @GetMapping("/value/list")
    @ApiOperation("规格值列表(按组)")
    public Result<List<SpecValue>> listValues(@RequestParam Long groupId) {
        return Result.success(specService.listValues(groupId));
    }

    @GetMapping("/value/{id}")
    @ApiOperation("规格值详情")
    public Result<SpecValue> getValue(@PathVariable Long id) {
        return Result.success(specService.getValueById(id));
    }

    @PostMapping("/value")
    @ApiOperation("新增规格值")
    public Result<Void> addValue(@RequestBody SpecValue value) {
        specService.addValue(value);
        return Result.success();
    }

    @PutMapping("/value")
    @ApiOperation("修改规格值")
    public Result<Void> updateValue(@RequestBody SpecValue value) {
        specService.updateValue(value);
        return Result.success();
    }

    @DeleteMapping("/value/{id}")
    @ApiOperation("删除规格值")
    public Result<Void> deleteValue(@PathVariable Long id) {
        specService.deleteValue(id);
        return Result.success();
    }

    // ========== 商品规格 ==========

    @GetMapping("/product/{productId}")
    @ApiOperation("商品规格关联列表")
    public Result<List<ProductSpec>> listProductSpecs(@PathVariable Long productId) {
        return Result.success(specService.listProductSpecs(productId));
    }

    @PostMapping("/product/{productId}")
    @ApiOperation("保存商品规格关联并生成SKU")
    public Result<List<Sku>> saveProductSpecs(@PathVariable Long productId, @RequestBody List<Long> valueIds) {
        specService.saveProductSpecs(productId, valueIds);
        List<Sku> skus = specService.generateSkus(productId);
        return Result.success("保存成功，已生成 " + skus.size() + " 个SKU", skus);
    }

    @PostMapping("/product/{productId}/generate-sku")
    @ApiOperation("重新生成SKU")
    public Result<List<Sku>> generateSkus(@PathVariable Long productId) {
        List<Sku> skus = specService.generateSkus(productId);
        return Result.success("已生成 " + skus.size() + " 个SKU", skus);
    }
}
