package com.eshop.manager.service;

import com.eshop.manager.entity.ProductSpec;
import com.eshop.manager.entity.Sku;
import com.eshop.manager.entity.SpecGroup;
import com.eshop.manager.entity.SpecValue;

import java.util.List;

public interface SpecService {

    // 规格组
    List<SpecGroup> listGroups();
    SpecGroup getGroupById(Long id);
    boolean addGroup(SpecGroup group);
    boolean updateGroup(SpecGroup group);
    boolean deleteGroup(Long id);

    // 规格值
    List<SpecValue> listValues(Long groupId);
    SpecValue getValueById(Long id);
    boolean addValue(SpecValue value);
    boolean updateValue(SpecValue value);
    boolean deleteValue(Long id);

    // 商品规格关联
    List<ProductSpec> listProductSpecs(Long productId);
    boolean saveProductSpecs(Long productId, List<Long> valueIds);

    // SKU 批量生成
    List<Sku> generateSkus(Long productId);
}
