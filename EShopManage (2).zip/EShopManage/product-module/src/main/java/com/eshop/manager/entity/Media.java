package com.eshop.manager.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("media")
public class Media {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;

    private String originalName;

    private String url;

    private String thumbnailUrl;

    private String mimeType;

    private Integer fileType;

    private Long size;

    private Integer width;

    private Integer height;

    private Integer duration;

    private String storageDriver;

    private String bucket;

    private String objectKey;

    private String md5;

    private String tags;

    private Long categoryId;

    private String createUser;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableLogic
    private Integer isDeleted;
}
