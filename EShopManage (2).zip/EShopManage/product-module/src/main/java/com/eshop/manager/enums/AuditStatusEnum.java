package com.eshop.manager.enums;

import com.baomidou.mybatisplus.annotation.IEnum;

public enum AuditStatusEnum implements IEnum<Integer> {
    NOT_SUBMITTED(0, "未提交"),
    PENDING(1, "待审核"),
    APPROVED(2, "审核通过"),
    REJECTED(3, "审核驳回");

    private final int value;
    private final String label;

    AuditStatusEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }
}
