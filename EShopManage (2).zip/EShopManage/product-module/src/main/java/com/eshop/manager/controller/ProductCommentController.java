package com.eshop.manager.controller;

import com.eshop.manager.common.PageResult;
import com.eshop.manager.common.Result;
import com.eshop.manager.entity.ProductComment;
import com.eshop.manager.service.ProductCommentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

@Api(tags = "商品评论")
@RestController
@RequestMapping("/api/comment")
public class ProductCommentController {

    private final ProductCommentService commentService;

    public ProductCommentController(ProductCommentService commentService) {
        this.commentService = commentService;
    }

    @GetMapping("/page")
    @ApiOperation("评论分页查询")
    public Result<PageResult<ProductComment>> page(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long productId,
            @RequestParam(required = false) Integer status) {
        return Result.success(PageResult.of(
                commentService.page(page, pageSize, productId, status)));
    }

    @PostMapping
    @ApiOperation("发表评论")
    public Result<Void> add(@RequestBody ProductComment comment) {
        commentService.add(comment);
        return Result.success();
    }

    @PutMapping("/{id}/audit")
    @ApiOperation("审核评论")
    public Result<Void> audit(@PathVariable Long id, @RequestParam Integer status) {
        commentService.audit(id, status);
        return Result.success();
    }

    @PutMapping("/{id}/reply")
    @ApiOperation("商家回复")
    public Result<Void> reply(@PathVariable Long id, @RequestParam String content) {
        commentService.reply(id, content);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除评论")
    public Result<Void> delete(@PathVariable Long id) {
        commentService.delete(id);
        return Result.success();
    }
}
