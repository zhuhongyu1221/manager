package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.SpecValue;

public interface SpecValueMapper extends BaseMapper<SpecValue> {
}
