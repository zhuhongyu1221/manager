package com.eshop.manager.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("product")
public class Product {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;

    private String subtitle;

    private Long brandId;

    private Long categoryId;

    private String categoryPath;

    private String unit;

    private String mainImage;

    private String images;

    private String description;

    private String keywords;

    private BigDecimal price;

    private BigDecimal originalPrice;

    private BigDecimal costPrice;

    private Integer stock;

    private Integer sales;

    private BigDecimal weight;

    private BigDecimal volume;

    private Integer status;

    private Integer isNew;

    private Integer isHot;

    private Integer isRecommend;

    private Integer auditStatus;

    private String auditRemark;

    private LocalDateTime publishTime;

    private LocalDateTime scheduledTime;

    private String createUser;

    private String updateUser;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableLogic
    private Integer isDeleted;
}
