$path = Join-Path (Get-Item "product-module\src\main\resources\static").FullName "index.html"
$text = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
$hasComment = $text.Contains("评论管理")
$hasCmtList = $text.Contains("cmtList")
Write-Host "评论管理: $hasComment"
Write-Host "cmtList: $hasCmtList"
