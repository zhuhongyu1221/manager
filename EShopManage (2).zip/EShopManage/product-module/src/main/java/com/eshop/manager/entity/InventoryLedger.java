package com.eshop.manager.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("inventory_ledger")
public class InventoryLedger {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long productId;

    private Long skuId;

    private Integer changeType;

    private Integer quantity;

    private Integer stockBefore;

    private Integer stockAfter;

    private String referenceType;

    private String referenceNo;

    private Long referenceId;

    private String remark;

    private String operator;

    private LocalDateTime operateTime;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
