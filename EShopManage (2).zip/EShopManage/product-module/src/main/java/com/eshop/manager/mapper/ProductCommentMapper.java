package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.ProductComment;

public interface ProductCommentMapper extends BaseMapper<ProductComment> {
}
