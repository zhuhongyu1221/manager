package com.eshop.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eshop.manager.entity.Media;

public interface MediaMapper extends BaseMapper<Media> {
}
