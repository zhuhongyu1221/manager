package com.eshop.manager.enums;

public enum MediaTypeEnum {
    MAIN_IMAGE(1, "主图"),
    DETAIL_IMAGE(2, "详情图"),
    CAROUSEL(3, "轮播图"),
    SKU_IMAGE(4, "SKU图"),
    VIDEO(5, "视频");

    private final int value;
    private final String label;

    MediaTypeEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public int getValue() { return value; }
    public String getLabel() { return label; }
}
