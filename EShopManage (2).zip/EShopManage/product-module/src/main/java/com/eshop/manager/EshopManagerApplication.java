package com.eshop.manager;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.eshop.manager.mapper")
public class EshopManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EshopManagerApplication.class, args);
    }
}
