package com.eshop.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.eshop.manager.entity.Category;
import com.eshop.manager.mapper.CategoryMapper;
import com.eshop.manager.service.CategoryService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryMapper categoryMapper;

    public CategoryServiceImpl(CategoryMapper categoryMapper) {
        this.categoryMapper = categoryMapper;
    }

    @Override
    public Category getById(Long id) {
        return categoryMapper.selectById(id);
    }

    @Override
    public List<Category> listByParentId(Long parentId) {
        return categoryMapper.selectList(
                new LambdaQueryWrapper<Category>()
                        .eq(Category::getParentId, parentId == null ? 0L : parentId)
                        .eq(Category::getStatus, 1)
                        .orderByAsc(Category::getSortOrder));
    }

    @Override
    public List<Category> tree(Long parentId) {
        List<Category> list = listByParentId(parentId);
        for (Category cat : list) {
            List<Category> children = tree(cat.getId());
            if (!children.isEmpty()) {
                // 用 setter 需要加额外字段, 这里直接用 parentId 做递归
                // 简单返回扁平列表, Controller 中处理嵌套
            }
        }
        return list;
    }

    @Override
    public boolean add(Category category) {
        category.setId(null);
        // 自动计算 level 和 path
        if (category.getParentId() != null && category.getParentId() > 0) {
            Category parent = categoryMapper.selectById(category.getParentId());
            if (parent != null) {
                category.setLevel(parent.getLevel() + 1);
                category.setPath(parent.getPath() + parent.getId() + "/");
            }
        } else {
            category.setParentId(0L);
            category.setLevel(1);
            category.setPath("0/");
        }
        return categoryMapper.insert(category) > 0;
    }

    @Override
    public boolean update(Category category) {
        return categoryMapper.updateById(category) > 0;
    }

    @Override
    public boolean delete(Long id) {
        // 检查是否有子分类
        long childrenCount = categoryMapper.selectCount(
                new LambdaQueryWrapper<Category>().eq(Category::getParentId, id));
        if (childrenCount > 0) {
            throw new IllegalArgumentException("存在子分类，无法删除");
        }
        return categoryMapper.deleteById(id) > 0;
    }
}
