package com.eshop.manager.controller;

import com.eshop.manager.common.PageResult;
import com.eshop.manager.common.Result;
import com.eshop.manager.entity.InventoryLedger;
import com.eshop.manager.service.InventoryLedgerService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

@Api(tags = "库存台账")
@RestController
@RequestMapping("/api/inventory")
public class InventoryLedgerController {

    private final InventoryLedgerService ledgerService;

    public InventoryLedgerController(InventoryLedgerService ledgerService) {
        this.ledgerService = ledgerService;
    }

    @GetMapping("/page")
    @ApiOperation("台账分页查询")
    public Result<PageResult<InventoryLedger>> page(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long productId,
            @RequestParam(required = false) Long skuId,
            @RequestParam(required = false) Integer changeType,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(PageResult.of(
                ledgerService.page(page, pageSize, productId, skuId, changeType, startDate, endDate)));
    }

    @PostMapping("/inbound")
    @ApiOperation("入库")
    public Result<Void> inbound(@RequestBody StockChangeReq req) {
        ledgerService.inbound(req.getProductId(), req.getSkuId(), req.getQuantity(),
                req.getRemark(), req.getOperator());
        return Result.success();
    }

    @PostMapping("/outbound")
    @ApiOperation("出库")
    public Result<Void> outbound(@RequestBody StockChangeReq req) {
        ledgerService.outbound(req.getProductId(), req.getSkuId(), req.getQuantity(),
                req.getRemark(), req.getOperator());
        return Result.success();
    }

    @PostMapping("/adjust")
    @ApiOperation("盘点调整")
    public Result<Void> adjust(@RequestBody AdjustReq req) {
        ledgerService.adjust(req.getProductId(), req.getSkuId(), req.getNewStock(),
                req.getRemark(), req.getOperator());
        return Result.success();
    }

    @lombok.Data
    public static class StockChangeReq {
        private Long productId;
        private Long skuId;
        private int quantity;
        private String remark;
        private String operator;
    }

    @lombok.Data
    public static class AdjustReq {
        private Long productId;
        private Long skuId;
        private int newStock;
        private String remark;
        private String operator;
    }
}
