package com.eshop.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.eshop.manager.entity.Brand;

import java.util.List;

public interface BrandService {
    Brand getById(Long id);
    IPage<Brand> page(int page, int pageSize, String keyword, Integer status);
    List<Brand> listAll();
    boolean add(Brand brand);
    boolean update(Brand brand);
    boolean delete(Long id);
    boolean batchEnable(List<Long> ids, Integer status);
}
